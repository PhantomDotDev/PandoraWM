#pragma once
#include <cstdint>
#include <X11/keysym.h>
#include "wm.h"

// ── Appearance ────────────────────────────────────────────────────────────────
const uint32_t BORDER_WIDTH   = 2;
const uint32_t BORDER_NORMAL  = 0x2a2a2a;
const uint32_t BORDER_FOCUSED = 0x88c0d0;
const uint32_t GAP            = 8;

// ── Layout ────────────────────────────────────────────────────────────────────
const float MASTER_RATIO_DEFAULT = 0.55f;

// ── Workspaces ────────────────────────────────────────────────────────────────
const int NUM_WORKSPACES = 9;

// ── Keybindings ───────────────────────────────────────────────────────────────
#define MOD Mod4Mask

const Key KEYS[] = {
    // modifier         key           function           arg
    { MOD,              XK_Return,    spawn,             (void*)"alacritty" },
    { MOD,              XK_d,         spawn,             (void*)"dmenu_run" },
    { MOD|ShiftMask,    XK_q,         kill_focused,      nullptr            },
    { MOD|ShiftMask,    XK_e,         quit,              nullptr            },
    { MOD,              XK_j,         focus_next,        nullptr            },
    { MOD,              XK_k,         focus_prev,        nullptr            },
    { MOD,              XK_h,         shrink_master,     nullptr            },
    { MOD,              XK_l,         grow_master,       nullptr            },
    { MOD,              XK_space,     toggle_layout,     nullptr            },
    { MOD,              XK_1,         goto_workspace,    (void*)0           },
    { MOD,              XK_2,         goto_workspace,    (void*)1           },
    { MOD,              XK_3,         goto_workspace,    (void*)2           },
    { MOD,              XK_4,         goto_workspace,    (void*)3           },
    { MOD,              XK_5,         goto_workspace,    (void*)4           },
    { MOD,              XK_6,         goto_workspace,    (void*)5           },
    { MOD,              XK_7,         goto_workspace,    (void*)6           },
    { MOD,              XK_8,         goto_workspace,    (void*)7           },
    { MOD,              XK_9,         goto_workspace,    (void*)8           },
    { MOD|ShiftMask,    XK_1,         move_to_workspace, (void*)0           },
    { MOD|ShiftMask,    XK_2,         move_to_workspace, (void*)1           },
    { MOD|ShiftMask,    XK_3,         move_to_workspace, (void*)2           },
    { MOD|ShiftMask,    XK_4,         move_to_workspace, (void*)3           },
    { MOD|ShiftMask,    XK_5,         move_to_workspace, (void*)4           },
    { MOD|ShiftMask,    XK_6,         move_to_workspace, (void*)5           },
    { MOD|ShiftMask,    XK_7,         move_to_workspace, (void*)6           },
    { MOD|ShiftMask,    XK_8,         move_to_workspace, (void*)7           },
    { MOD|ShiftMask,    XK_9,         move_to_workspace, (void*)8           },
};

const int KEYS_LEN = (int)(sizeof(KEYS) / sizeof(KEYS[0]));
