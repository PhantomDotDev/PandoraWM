#pragma once
#include <X11/Xlib.h>
#include <vector>
#include <string>

// ── Types ─────────────────────────────────────────────────────────────────────

struct Client {
    Window win;
    int    workspace;
    bool   floating;
};

enum class Layout { Tiling, Monocle };

struct Key {
    unsigned int  mod;
    KeySym        sym;
    void        (*fn)(void*);
    void*         arg;
};

// ── Function declarations (used in config.h) ──────────────────────────────────
void spawn           (void* arg);   // arg = const char* command
void kill_focused    (void* arg);
void quit            (void* arg);
void focus_next      (void* arg);
void focus_prev      (void* arg);
void grow_master     (void* arg);
void shrink_master   (void* arg);
void toggle_layout   (void* arg);
void goto_workspace  (void* arg);   // arg = (void*)(intptr_t)index
void move_to_workspace(void* arg);
