# phantom-wm

A minimal, extensible X11 tiling window manager written in C++20.
~350 lines. No dependencies beyond libX11.

## Build

```sh
sudo pacman -S libx11
make
sudo make install   # optional
```

## Run

Add to `~/.xinitrc`:
```sh
exec phantom-wm
```
Or launch from a display manager session entry.

## Keybindings (defaults)

| Key                | Action                        |
|--------------------|-------------------------------|
| Super+Return       | Launch alacritty              |
| Super+d            | dmenu_run                     |
| Super+j/k          | Focus next/prev window        |
| Super+h/l          | Shrink/grow master pane       |
| Super+Space        | Toggle tiling ↔ monocle       |
| Super+1…9          | Switch workspace              |
| Super+Shift+1…9    | Move window to workspace      |
| Super+Shift+q      | Kill focused window           |
| Super+Shift+e      | Quit WM                       |

## Extending

The code is intentionally flat and readable. Common extension points:

- **New keybinding** → add a `Key` entry in `config.h` and a function in `main.cpp`
- **New layout** → add a `Layout` enum value, handle it in `tile()`
- **Floating windows** → check `c.floating` in `tile()` and skip those clients
- **Status bar** → draw on a dedicated `XCreateSimpleWindow` in `setup()`
- **Mouse move/resize** → handle `ButtonPress` + `MotionNotify` events

## File overview

```
main.cpp   — everything: event loop, layout, actions
wm.h       — structs (Client, Key, Layout) + function declarations
config.h   — keybindings + appearance constants
Makefile
```
