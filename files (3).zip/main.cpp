//  phantom-wm — a minimal extensible X11 tiling window manager
//  Build: g++ -std=c++20 -O2 -o phantom-wm main.cpp -lX11

#include "wm.h"
#include <X11/Xlib.h>
#include <X11/keysym.h>
#include <X11/Xatom.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <csignal>
#include <vector>
#include <algorithm>
#include <unistd.h>

// ── Forward-declare config constants ─────────────────────────────────────────
// (defined after config.h is included at the bottom)
extern const uint32_t BORDER_WIDTH;
extern const uint32_t BORDER_NORMAL;
extern const uint32_t BORDER_FOCUSED;
extern const uint32_t GAP;
extern const float    MASTER_RATIO_DEFAULT;
extern const int      NUM_WORKSPACES;
extern const Key      KEYS[];
extern const int      KEYS_LEN;

// ── State ─────────────────────────────────────────────────────────────────────

static Display*            dpy;
static Window              root;
static int                 screen_w, screen_h;
static bool                running = true;

static std::vector<Client> clients;
static int                 focused_idx   = -1;
static int                 cur_workspace = 0;
static Layout              cur_layout    = Layout::Tiling;
static float               master_ratio  = 0.55f;

// ── Helpers ───────────────────────────────────────────────────────────────────

static std::vector<Client*> visible() {
    std::vector<Client*> v;
    for (auto& c : clients)
        if (c.workspace == cur_workspace)
            v.push_back(&c);
    return v;
}

static Client* focused_client() {
    if (focused_idx < 0 || focused_idx >= (int)clients.size()) return nullptr;
    return &clients[focused_idx];
}

static int visible_index(Client* c) {
    auto v = visible();
    for (int i = 0; i < (int)v.size(); i++)
        if (v[i] == c) return i;
    return -1;
}

static void set_border(Window w, uint32_t color) {
    XSetWindowBorder(dpy, w, color);
}

static void focus(Client* c) {
    if (auto* old = focused_client())
        set_border(old->win, BORDER_NORMAL);

    if (!c) { focused_idx = -1; return; }

    focused_idx = (int)(c - clients.data());
    XSetInputFocus(dpy, c->win, RevertToPointerRoot, CurrentTime);
    XRaiseWindow(dpy, c->win);
    set_border(c->win, BORDER_FOCUSED);
}

static void focus_first_visible() {
    auto v = visible();
    focus(v.empty() ? nullptr : v[0]);
}

// ── Layout ────────────────────────────────────────────────────────────────────

static void tile() {
    auto v = visible();
    int  n = (int)v.size();
    if (n == 0) return;

    int g  = (int)GAP;
    int bw = (int)BORDER_WIDTH * 2;

    if (cur_layout == Layout::Monocle) {
        for (auto* c : v)
            XMoveResizeWindow(dpy, c->win,
                g, g,
                screen_w - 2*g - bw,
                screen_h - 2*g - bw);
        return;
    }

    if (n == 1) {
        XMoveResizeWindow(dpy, v[0]->win,
            g, g,
            screen_w - 2*g - bw,
            screen_h - 2*g - bw);
        return;
    }

    int master_w = (int)((screen_w - 3*g) * master_ratio);
    int stack_w  = screen_w - master_w - 3*g;
    int stack_n  = n - 1;
    int stack_h  = (screen_h - (stack_n + 1) * g) / stack_n;

    XMoveResizeWindow(dpy, v[0]->win,
        g, g,
        master_w - bw,
        screen_h - 2*g - bw);

    for (int i = 1; i < n; i++) {
        XMoveResizeWindow(dpy, v[i]->win,
            master_w + 2*g,
            g + (i-1) * (stack_h + g),
            stack_w - bw,
            stack_h - bw);
    }
}

// ── Actions ───────────────────────────────────────────────────────────────────

void spawn(void* arg) {
    const char* cmd = static_cast<const char*>(arg);
    if (fork() == 0) {
        setsid();
        execlp("sh", "sh", "-c", cmd, nullptr);
        _exit(1);
    }
}

void kill_focused(void*) {
    Client* c = focused_client();
    if (!c) return;
    Atom wm_protocols = XInternAtom(dpy, "WM_PROTOCOLS", False);
    Atom wm_delete    = XInternAtom(dpy, "WM_DELETE_WINDOW", False);
    Atom* protos; int n;
    if (XGetWMProtocols(dpy, c->win, &protos, &n)) {
        for (int i = 0; i < n; i++) {
            if (protos[i] == wm_delete) {
                XEvent ev = {};
                ev.type                 = ClientMessage;
                ev.xclient.window       = c->win;
                ev.xclient.message_type = wm_protocols;
                ev.xclient.format       = 32;
                ev.xclient.data.l[0]    = (long)wm_delete;
                ev.xclient.data.l[1]    = CurrentTime;
                XSendEvent(dpy, c->win, False, NoEventMask, &ev);
                XFree(protos);
                return;
            }
        }
        XFree(protos);
    }
    XDestroyWindow(dpy, c->win);
}

void quit(void*)          { running = false; }

void focus_next(void*) {
    auto v = visible();
    if (v.empty()) return;
    int vi = visible_index(focused_client());
    focus(v[(vi + 1) % (int)v.size()]);
}

void focus_prev(void*) {
    auto v = visible();
    if (v.empty()) return;
    int vi = visible_index(focused_client());
    focus(v[(vi - 1 + (int)v.size()) % (int)v.size()]);
}

void grow_master(void*)   { master_ratio = std::min(master_ratio + 0.05f, 0.9f); tile(); }
void shrink_master(void*) { master_ratio = std::max(master_ratio - 0.05f, 0.1f); tile(); }

void toggle_layout(void*) {
    cur_layout = (cur_layout == Layout::Tiling) ? Layout::Monocle : Layout::Tiling;
    tile();
}

void goto_workspace(void* arg) {
    int ws = (int)(intptr_t)arg;
    if (ws == cur_workspace) return;
    for (auto& c : clients)
        if (c.workspace == cur_workspace) XUnmapWindow(dpy, c.win);
    cur_workspace = ws;
    for (auto& c : clients)
        if (c.workspace == cur_workspace) XMapWindow(dpy, c.win);
    tile();
    focus_first_visible();
}

void move_to_workspace(void* arg) {
    Client* c = focused_client();
    if (!c) return;
    int ws = (int)(intptr_t)arg;
    if (ws == cur_workspace) return;
    c->workspace = ws;
    XUnmapWindow(dpy, c->win);
    focused_idx = -1;
    tile();
    focus_first_visible();
}

// ── X11 event handlers ────────────────────────────────────────────────────────

static void on_map_request(XMapRequestEvent& e) {
    for (auto& c : clients)
        if (c.win == e.window) { XMapWindow(dpy, e.window); tile(); return; }
    XSetWindowBorderWidth(dpy, e.window, BORDER_WIDTH);
    set_border(e.window, BORDER_NORMAL);
    XSelectInput(dpy, e.window, EnterWindowMask | FocusChangeMask);
    clients.push_back({ e.window, cur_workspace, false });
    XMapWindow(dpy, e.window);
    tile();
    focus(&clients.back());
}

static void on_destroy_notify(XDestroyWindowEvent& e) {
    auto it = std::find_if(clients.begin(), clients.end(),
                           [&](const Client& c){ return c.win == e.window; });
    if (it == clients.end()) return;
    bool was_focused = (&*it == focused_client());
    clients.erase(it);
    if (was_focused) { focused_idx = -1; focus_first_visible(); }
    tile();
}

static void on_enter_notify(XCrossingEvent& e) {
    if (e.mode != NotifyNormal) return;
    auto it = std::find_if(clients.begin(), clients.end(),
                           [&](const Client& c){ return c.win == e.window; });
    if (it != clients.end()) focus(&*it);
}

static void on_key_press(XKeyEvent& e) {
    KeySym sym = XLookupKeysym(&e, 0);
    for (int i = 0; i < KEYS_LEN; i++)
        if (KEYS[i].sym == sym && (e.state & KEYS[i].mod) == KEYS[i].mod)
            KEYS[i].fn(KEYS[i].arg);
}

static void on_configure_request(XConfigureRequestEvent& e) {
    XWindowChanges wc;
    wc.x = e.x; wc.y = e.y; wc.width = e.width; wc.height = e.height;
    wc.border_width = e.border_width; wc.sibling = e.above; wc.stack_mode = e.detail;
    XConfigureWindow(dpy, e.window, (unsigned)e.value_mask, &wc);
}

// ── Setup / teardown ──────────────────────────────────────────────────────────

static int x_error_handler(Display*, XErrorEvent* e) {
    if (e->error_code == BadWindow) return 0;
    char buf[256];
    XGetErrorText(dpy, e->error_code, buf, sizeof buf);
    fprintf(stderr, "phantom-wm: X error: %s\n", buf);
    return 0;
}

static void grab_keys() {
    XUngrabKey(dpy, AnyKey, AnyModifier, root);
    for (int i = 0; i < KEYS_LEN; i++) {
        KeyCode kc = XKeysymToKeycode(dpy, KEYS[i].sym);
        if (kc) XGrabKey(dpy, kc, KEYS[i].mod, root, True,
                         GrabModeAsync, GrabModeAsync);
    }
}

static void setup() {
    dpy = XOpenDisplay(nullptr);
    if (!dpy) { fputs("phantom-wm: cannot open display\n", stderr); exit(1); }
    XSetErrorHandler(x_error_handler);
    screen_w    = DisplayWidth (dpy, DefaultScreen(dpy));
    screen_h    = DisplayHeight(dpy, DefaultScreen(dpy));
    root        = DefaultRootWindow(dpy);
    master_ratio = MASTER_RATIO_DEFAULT;
    XSelectInput(dpy, root,
        SubstructureRedirectMask | SubstructureNotifyMask | KeyPressMask);
    grab_keys();
}

static void run() {
    XEvent ev;
    while (running && !XNextEvent(dpy, &ev)) {
        switch (ev.type) {
            case MapRequest:       on_map_request      (ev.xmaprequest);      break;
            case DestroyNotify:    on_destroy_notify   (ev.xdestroywindow);   break;
            case EnterNotify:      on_enter_notify     (ev.xcrossing);        break;
            case KeyPress:         on_key_press        (ev.xkey);             break;
            case ConfigureRequest: on_configure_request(ev.xconfigurerequest);break;
            default: break;
        }
    }
}

// ── Config (included last — references functions defined above) ───────────────

#include "config.h"

// ── Entry point ───────────────────────────────────────────────────────────────

int main() {
    signal(SIGCHLD, SIG_IGN);
    setup();
    run();
    XCloseDisplay(dpy);
}
